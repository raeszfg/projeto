CREATE DATABASE IF NOT EXISTS dbsiteg DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dbsiteg;


DROP TABLE IF EXISTS usuarios;

CREATE TABLE usuarios (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome VARCHAR(50) NOT NULL,
  perfil varchar(5) NOT NULL,
  email VARCHAR(255) NOT NULL,
  senha VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_usuarios_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO usuarios (nome, perfil, email, senha) VALUES
('Admin', 'Admin', 'admin@exemplo.com', '$2y$12$hgp0eHsLqms7lyCaETAhQujcacTxzCaajw4fMIvdJxG2JOyktbIaG');
INSERT INTO usuarios (nome, perfil, email, senha) VALUES
('Usuario','User', 'teste@exemplo.com', '$2y$10$cZ.d26bqpB.W7a4w9SaIkuNJ.DiG3kc6Mt37d2HWulyk.im0pmy/.');

DROP TABLE IF EXISTS produtos;

CREATE TABLE produtos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  descricao TEXT NOT NULL,
  efeito VARCHAR(100) NOT NULL,
  preco DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (id)
);

INSERT INTO produtos (nome, descricao, efeito, preco) VALUES
('ProdutoA', 'Descricao do Produto A', 'EfeitoA', 19.90);
INSERT INTO produtos (nome, descricao, efeito, preco) VALUES
('ProdutoB', 'Descricao do Produto B', 'EfeitoB', 29.90);

