<?php
class ProdutoRepositorio
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    private function formarObjeto(array $dados): Produto
    {
        return new Produto(
            (int)$dados['id'],
            $dados['nome'],
            $dados['descricao'],
            $dados['efeito'],
            (float)$dados['preco']
        );
    }

    public function buscarPorId(int $id): ?Produto
    {
        $sql = "SELECT id, nome, descricao, efeito, preco FROM produtos WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(1, $id, PDO::PARAM_INT);
        $stmt->execute();
        $dados = $stmt->fetch();
        return $dados ? $this->formarObjeto($dados) : null;
    }

    public function buscarTodos(): array
    {
        $sql = "SELECT id, nome, descricao, efeito, preco FROM produtos";
        $stmt = $this->pdo->query($sql);
        $dados = $stmt->fetchAll();
        $produtos = [];
        foreach ($dados as $linha) {
            $produtos[] = $this->formarObjeto($linha);
        }
        return $produtos;
    }

    public function salvar(Produto $produto): void
    {
        $sql = "INSERT INTO produtos (nome, descricao, efeito, preco) VALUES (?, ?, ?, ?)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(1, $produto->getNome());
        $stmt->bindValue(2, $produto->getDescricao());
        $stmt->bindValue(3, $produto->getEfeito());
        $stmt->bindValue(4, $produto->getPreco());
        $stmt->execute();
    }

    public function atualizar(Produto $produto): void
    {
        $sql = "UPDATE produtos SET nome = ?, descricao = ?, efeito = ?, preco = ? WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(1, $produto->getNome());
        $stmt->bindValue(2, $produto->getDescricao());
        $stmt->bindValue(3, $produto->getEfeito());
        $stmt->bindValue(4, $produto->getPreco());
        $stmt->bindValue(5, $produto->getId(), PDO::PARAM_INT);
        $stmt->execute();
    }

    public function remover(int $id): void
    {
        $sql = "DELETE FROM produtos WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(1, $id, PDO::PARAM_INT);
        $stmt->execute();
    }
}
?>
