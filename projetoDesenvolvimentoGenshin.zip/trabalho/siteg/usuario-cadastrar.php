<?php
session_start();
require_once 'src/conexao-bd.php';
require_once 'src/Repositorio/UsuarioRepositorio.php';
require_once 'src/Modelo/Usuario.php';

$erro = '';
$sucesso = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');

    if(!$nome || !$email || !$senha){
        $erro = 'Preencha todos os campos.';
    } else {
        $repo = new UsuarioRepositorio($pdo);
        
        if($repo->buscarPorEmail($email)){
            $erro = 'Este e-mail já está cadastrado.';
        } else {
            $usuario = new Usuario(0, $nome, $email, $senha, 'User');
            $repo->salvar($usuario);
            $sucesso = 'Usuário cadastrado com sucesso! Você já pode <a href="login.php">entrar</a>.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/admin.css">
<link rel="stylesheet" href="css/login.css">
<title>Cadastro de Usuário</title>
</head>
<body>
<main>
    <section class="container-form">
        <div class="form-wrapper">
            <h2>Cadastro de Usuário</h2>
            <?php if($erro): ?>
                <p class="mensagem-erro"><?php echo htmlspecialchars($erro); ?></p>
            <?php elseif($sucesso): ?>
                <p class="mensagem-sucesso"><?php echo $sucesso; ?></p>
            <?php endif; ?>
            <form action="" method="post">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" placeholder="Digite seu nome" required>

                <label for="email">E-mail:</label>
                <input type="email" id="email" name="email" placeholder="Digite seu e-mail" required>

                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" placeholder="Digite sua senha" required>

                <input type="submit" class="botao-cadastrar" value="Cadastrar">
            </form>

            <p style="text-align:center; margin-top: 10px;">
                Já tem conta? <a href="login.php">Entrar</a>
            </p>
        </div>
    </section>
</main>
</body>
</html>
