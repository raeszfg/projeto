<?php
session_start();

if(!isset($_SESSION['usuario'])){
    header('Location: login.php');
    exit;
}

require_once 'src/conexao-bd.php';
require_once 'src/Repositorio/ProdutoRepositorio.php';
require_once 'src/Repositorio/UsuarioRepositorio.php';
require_once 'src/Modelo/Produto.php';
require_once 'src/Modelo/Usuario.php';

$repoProduto = new ProdutoRepositorio($pdo);
$repoUsuario = new UsuarioRepositorio($pdo);


if($_SERVER['REQUEST_METHOD'] === 'POST') {

    if(isset($_POST['excluir_produto_id'])){
        $idProduto = (int)$_POST['excluir_produto_id'];
        $repoProduto->remover($idProduto);
        header('Location: admin.php?aba=produtos');
        exit;
    }


    if(isset($_POST['excluir_usuario_id'])){
        $idUsuario = (int)$_POST['excluir_usuario_id'];
        $repoUsuario->excluir($idUsuario);
        header('Location: admin.php?aba=usuarios');
        exit;
    }


    if(isset($_POST['promover_usuario_id'])){
        $idUsuario = (int)$_POST['promover_usuario_id'];
        $repoUsuario->tornarAdmin($idUsuario);
        header('Location: admin.php?aba=usuarios');
        exit;
    }


    if(isset($_POST['logout'])){
        session_destroy();
        header('Location: login.php');
        exit;
    }
}


$aba = $_GET['aba'] ?? 'produtos';


$termoProduto = $_GET['pesquisa'] ?? '';
$produtos = $repoProduto->buscarTodos();
if($aba === 'produtos' && $termoProduto){
    $produtos = array_filter($produtos, fn($p) => stripos($p->getNome(), $termoProduto) !== false);
}


$termoUsuario = $_GET['pesquisa_usuario'] ?? '';
$usuarios = $repoUsuario->listar();
if($aba === 'usuarios' && $termoUsuario){
    $usuarios = array_filter($usuarios, fn($u) => stripos($u->getNome(), $termoUsuario) !== false);
}

$usuarioLogado = $_SESSION['usuario'];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/admin.css">
<title>Painel Administrativo</title>
</head>
<body>
<header class="header-admin">
    <h1>Painel Administrativo</h1>
    <form method="post">
        <button type="submit" name="logout" class="botao-home">Sair</button>
    </form>
</header>

<nav class="menu-admin">
    <a href="?aba=produtos" class="<?php echo $aba==='produtos'?'ativo':''; ?>">Produtos</a>
    <a href="?aba=usuarios" class="<?php echo $aba==='usuarios'?'ativo':''; ?>">Usuários</a>
</nav>

<section class="container-table">

<?php if($aba === 'produtos'): ?>
    <form class="pesquisa-container" method="get">
        <input type="hidden" name="aba" value="produtos">
        <input type="text" name="pesquisa" placeholder="Pesquisar produto..." value="<?php echo htmlspecialchars($termoProduto); ?>">
        <button type="submit">🔍</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Efeito</th>
                <th>Preço</th>
                <th colspan="2">Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($produtos as $p): ?>
            <tr>
                <td><?php echo htmlspecialchars($p->getNome()); ?></td>
                <td><?php echo htmlspecialchars($p->getDescricao()); ?></td>
                <td><?php echo htmlspecialchars($p->getEfeito()); ?></td>
                <td><?php echo htmlspecialchars($p->getPreco()); ?></td>
                <td><a class="botao-editar" href="editar-produto.php?id=<?php echo $p->getId(); ?>">Editar</a></td>
                <td>
                    <form method="post">
                        <input type="hidden" name="excluir_produto_id" value="<?php echo $p->getId(); ?>">
                        <input type="submit" class="botao-excluir" value="Excluir">
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="cadastrar-produto.php" class="botao-cadastrar">+ Adicionar Produto</a>

<?php elseif($aba === 'usuarios'): ?>
    <form class="pesquisa-container" method="get">
        <input type="hidden" name="aba" value="usuarios">
        <input type="text" name="pesquisa_usuario" placeholder="Pesquisar usuário..." value="<?php echo htmlspecialchars($termoUsuario); ?>">
        <button type="submit">🔍</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Perfil</th>
                <th colspan="2">Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($usuarios as $u): ?>
            <tr>
                <td><?php echo htmlspecialchars($u->getNome()); ?></td>
                <td><?php echo htmlspecialchars($u->getEmail()); ?></td>
                <td><?php echo htmlspecialchars($u->getPerfil()); ?></td>
                <td>
                    <?php if($u->getPerfil() !== 'Admin'): ?>
                    <form method="post">
                        <input type="hidden" name="promover_usuario_id" value="<?php echo $u->getId(); ?>">
                        <input type="submit" class="botao-editar" value="Tornar Admin">
                    </form>
                    <?php endif; ?>
                </td>
                <td>
                    <form method="post">
                        <input type="hidden" name="excluir_usuario_id" value="<?php echo $u->getId(); ?>">
                        <input type="submit" class="botao-excluir" value="Excluir">
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="usuario-cadastrar.php" class="botao-cadastrar">+ Adicionar Usuário</a>
<?php endif; ?>

</section>
</body>
</html>
