<?php
session_start();

if(!isset($_SESSION['usuario'])){
    header('Location: login.php');
    exit;
}

require_once 'src/conexao-bd.php';
require_once 'src/Repositorio/ProdutoRepositorio.php';
require_once 'src/Modelo/Produto.php';

$repo = new ProdutoRepositorio($pdo);
$erro = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $nome = trim($_POST['nome']);
    $descricao = trim($_POST['descricao']);
    $efeito = trim($_POST['efeito']);
    $preco = trim($_POST['preco']);

    if($nome && $descricao && $efeito && $preco){
        $produto = new Produto(0, $nome, $descricao, $efeito, $preco);
        $repo->salvar($produto);
        header('Location: admin.php');
        exit;
    } else {
        $erro = "Todos os campos são obrigatórios.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/form.css">
    <title>Cadastrar Produto</title>
</head>
<body>
    <header class="header-admin">
        <button class="botao-menu">☰ Menu</button>
        <h1>Cadastro de Produtos</h1>
        <button class="botao-home">Página Inicial</button>
    </header>

    <section class="container-form">
        <?php if($erro) echo "<p class='mensagem-erro'>$erro</p>"; ?>
        <form method="post">
            <input type="text" name="nome" placeholder="Nome do Produto" required>
            <input type="text" name="descricao" placeholder="Descrição" required>
            <input type="text" name="efeito" placeholder="Efeito" required>
            <input type="text" name="preco" placeholder="Preço" required>
            <button type="submit" class="botao-cadastrar">Cadastrar Produto</button>
        </form>
    </section>
</body>
</html>
