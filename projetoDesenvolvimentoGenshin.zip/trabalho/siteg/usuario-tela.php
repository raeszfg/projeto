<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

require_once 'src/conexao-bd.php';
require_once 'src/Repositorio/ProdutoRepositorio.php';
require_once 'src/Modelo/Produto.php';

$usuarioLogado = $_SESSION['usuario']; 

$repoProduto = new ProdutoRepositorio($pdo);
$produtos = $repoProduto->buscarTodos();


$termoProduto = $_GET['pesquisa'] ?? '';
if ($termoProduto) {
    $produtos = array_filter($produtos, fn($p) => stripos($p->getNome(), $termoProduto) !== false);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/usuario-tela.css">
<title>Usuário - Produtos</title>
</head>
<body>
<header class="header-usuario">
    <h1>Produtos</h1>
    <form method="post" action="logout.php">
        <button type="submit" class="botao-home">Sair</button>
    </form>
</header>

<form class="pesquisa-container" method="get">
    <input type="text" name="pesquisa" placeholder="Pesquisar produto..." value="<?php echo htmlspecialchars($termoProduto); ?>">
    <button type="submit">🔍</button>
</form>

<section class="container-table">
<table>
    <thead>
        <tr>
            <th>Nome</th>
            <th>Descrição</th>
            <th>Efeito</th>
            <th>Preço</th>
            <th>Comprar</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($produtos as $p): ?>
        <tr>
            <td><?php echo htmlspecialchars($p->getNome()); ?></td>
            <td><?php echo htmlspecialchars($p->getDescricao()); ?></td>
            <td><?php echo htmlspecialchars($p->getEfeito()); ?></td>
            <td><?php echo htmlspecialchars($p->getPreco()); ?></td>
            <td><button class="botao-comprar">Comprar</button></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</section>
</body>
</html>
